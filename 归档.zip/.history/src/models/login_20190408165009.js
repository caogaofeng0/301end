import { routerRedux } from 'dva/router';
import { stringify } from 'qs';
import { fakeAccountLogin } from '@/services/api';
import { setAuthority } from '@/utils/authority';
import { reloadAuthorized } from '@/utils/Authorized';

export default {
  namespace: 'login',
  state: {
    status: undefined,
  },

  effects: {
    *login({ payload }, { call, put }) {
      const response = yield call(fakeAccountLogin, payload);
      yield put({
        type: 'changeLoginStatus',
        payload: response,
      });
      if (response.status === 'ok') {
        // eslint-disable-next-line func-names
          let EXPIRE_IN_15MIN = 3000; // 15 min
          let logoutTimer = '';
          logout = () {
            // do your logout logic here
            console.log("log2----------->")
          }
          setTime = ()=> {
            logoutTimer = setTimeout(logout, EXPIRE_IN_15MIN);
          }
          setTime()
          function userActionHandler () {
            clearTimeout(logoutTimer);
            setTime()
          }
          
          window.addEventListener('click', ()=> {
             userActionHandler()
          })
          // TODO: bind userActionHandler to any 'user action' you need
        window.location.href = '/';
      }
    },

    *logout(_, { put }) {
      yield put({
        type: 'changeLoginStatus',
        payload: {
          status: false,
          currentAuthority: 'guest',
        },
      });
      reloadAuthorized();
      yield put(
        routerRedux.replace({
          pathname: '/user/login',
          search: stringify({
            redirect: window.location.href,
          }),
        })
      );
    },
  },

  reducers: {
    changeLoginStatus(state, { payload }) {
      setAuthority(payload.currentAuthority);
      return {
        ...state,
        status: payload.status,
        type: payload.type,
      };
    },
  },
};
