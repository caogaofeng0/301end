export default {
  'menu.home': '首',
  'menu.login': '登錄',
  
  'menu.hospitalUser': '医院用户管理',
  'menu.hospitalUser.list': '医院用户列表',
  'menu.hospitalUser.bind': '绑定',
  'menu.hospitalUser.history': '绑定历史',
  'menu.business': '医院业务管理',
  'menu.business.no': '挂号统计',
  'menu.business.user': '用户统计',
  'menu.business.workplace': '统计',
  'menu.info': '医院信息管理',
  'menu.info.InfoDepart': '科室信息',
  'menu.info.settings': '个人设置',
};
