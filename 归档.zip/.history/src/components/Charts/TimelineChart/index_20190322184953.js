import React from 'react';
import { Chart, Tooltip, Geom, Legend, Axis } from 'bizcharts';
import autoHeight from '../autoHeight';
import styles from './index.less';

@autoHeight()
class TimelineChart extends React.Component {
  render() {
    const {
      title,
      height = 400,
      padding = [60, 20, 40, 40],
      borderWidth = 2,
      data: sourceData,
    } = this.props;
  
    console.log(sourceData, "sourceData,----------->")

    const data = [
      {
        year: "1991",
        value: 3
      },
      {
        year: "1992",
        value: 4
      },
      {
        year: "1993",
        value: 3.5
      },
      {
        year: "1994",
        value: 5
      },
      {
        year: "1995",
        value: 4.9
      },
      {
        year: "1996",
        value: 6
      },
      {
        year: "1997",
        value: 7
      },
      {
        year: "1998",
        value: 9
      },
      {
        year: "1999",
        value: 13
      }
    ];
    const cols = {
      value: {
        min: 0
      },
      year: {
        range: [0, 1]
      }
    };

    return (
      <div className={styles.timelineChart} style={{ height: height + 30 }}>
        <div>
          {title && <h4>{title}</h4>}
          <Chart height={height} padding={padding} data={data} scale={cols} forceFit>
            <Axis name="year" />
            <Tooltip />
            <Legend name="key" position="top" />
            <Geom type="line" position="year*value" size={borderWidth} color="key" />
          </Chart>
        </div>
      </div>
    );
  }
}

export default TimelineChart;
